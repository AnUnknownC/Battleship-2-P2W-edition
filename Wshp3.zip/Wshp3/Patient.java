class Patient {

    int age;
    String name;
    String condition;
    String id;
    String diagnostic;
    String lifeExpectancy;

    public void patient(String name, String condition, String id, String diagnostic, String lifeExpectancy, int age) {
        this.age = age;
        this.name = name;
        this.condition = condition;
        this.id = id;
        this.diagnostic = diagnostic;
        this.lifeExpectancy = lifeExpectancy;

    }

    public void givedata(){
        System.out.println("Patient: " + name + " Age: " + age + " Condition: " + 
        condition + " ID: " + id + " Life expectancy: " + lifeExpectancy );
    }

}

