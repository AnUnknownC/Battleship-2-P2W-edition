class Patient {

    int age;
    String name;
    String condition;
    String id;
    String diagnostic;
    String lifeExpectancy;

    public void Patient(String name, String condition, String id, String diagnostic, String lifeExpectancy) {
        this.age = age;
        this.name = name;
        this.condition = condition;
        this.id = id;
        this.diagnostic = diagnostic;
        this.lifeExpectancy = lifeExpectancy;

    }

}

