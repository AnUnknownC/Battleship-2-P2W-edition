public class Main {
    
    public static void main(String[] args){
        Patient p1 = new Patient();
        p1.age = 12;
        p1.name = "Estebitan";
        p1.condition = "Cancer";
        p1.id = "1232132323";
        p1.diagnostic = "Cancer of prostate";
        p1.lifeExpectancy = "less than a month";

        System.out.println("Patient: " + p1.name + "age: " + );
        
        

    }
}
