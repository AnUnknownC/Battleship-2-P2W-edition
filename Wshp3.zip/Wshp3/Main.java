public class Main {
    
    public static void main(String[] args){
        Patient p1 = new Patient();
        p1.age = 30;
        p1.name = "Jhon";
        p1.condition = "Cancer";
        p1.id = "1232132323";
        p1.lifeExpectancy = "less than 3 years";

        p1.givedata();
        
        
    
    }
}
