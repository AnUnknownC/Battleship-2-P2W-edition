package vista;
import modelo.Biblioteca;
import modelo.Material;
import modelo.Libro;
import modelo.Revista;
import modelo.EjemplarLibro;

public class Principal {
    
    
    public static void main(String[] args) {

        Libro manga = new Libro("Jujutsu Kaisen", "Ingles", "Shonen", 
        "Gege Akutami", "Shonen Jump", 2020, "XY18283", 10);

        System.out.println(manga.getLocalizacion());

        

    }

}
