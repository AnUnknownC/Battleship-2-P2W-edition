package modelo; 
import java.util.ArrayList;

public class Biblioteca {
    
    private String nombre;
    private boolean estaAbierta;
    private ArrayList<Libro> Libros;
    private Material materiales;
	

    public Biblioteca(String nombre) {
        this.nombre = nombre;
        this.estaAbierta = false;
        this.Libros = new ArrayList<Libro>();
	}

    public String getNombre(){
        return nombre;
    }

    public boolean isEstaAbierta() {
        return estaAbierta;
    }

    public void setEstaAbierta(boolean estaAbierta) {
        this.estaAbierta = estaAbierta;
    }

    /*public adicionarLibros (Libro l){
        Panas en la foto que envio daniel dice que Adicionar libros, pero como asi eso se hace aca? (╯°□°）╯︵ ┻━┻   }*/
    
}
