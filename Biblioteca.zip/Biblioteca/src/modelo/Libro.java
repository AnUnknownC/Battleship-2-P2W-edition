package modelo;
import java.util.ArrayList;
public class Libro extends Material {

    private ArrayList<EjemplarLibro> copias;
    private String genero;
    private String isbn;
    private int cantidad;
    private Material[] material;
    
    public Libro(String nombre, String lenguaje, String genero, String autor, String editorial, 
    int anioDePublicacion,String localizacion,int copias) {
        super(nombre, lenguaje, autor, editorial, anioDePublicacion, localizacion, copias);
        this.copias = new ArrayList<>();
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getIsbn(String isbn){
        return isbn;
    }

    //metodo adicionar libros

    public void adicionarLibros(int cantidad) {
        for (int i = 0; i <= cantidad; i++) {
            EjemplarLibro tmp = new EjemplarLibro(this);
            this.copias.add(tmp);
        }
    }

    //metodo para eliminar libros

    public void eliminarLibro(EjemplarLibro libro) {
        copias.remove(libro);
    }

    /*metodo Buscar por genero
    *Istanceof = verificar si el objeto m es una instancia de la clase Libro, 
    * ya que Material podría tener otras subclases diferentes de Libro.
    */

    public ArrayList<Libro> buscaPorGenero (String generoBuscado){
        ArrayList<Libro> librosPorGenero = new ArrayList<>();
        for (Material i: material){
            if (i instanceof Libro libro && libro.getGenero().equalsIgnoreCase(generoBuscado)) { 
                librosPorGenero.add(libro); 
            }
        }
        return librosPorGenero;
    }

    // Buscar Libros por autor

    public ArrayList<Libro> buscaPorAutor (String autorBuscado){
        ArrayList<Libro> librosPorAutor = new ArrayList<>();
        for (Material i: material){
            if (i instanceof Libro libro && libro.getAutor().equalsIgnoreCase(autorBuscado)) { 
                librosPorAutor.add(libro); 
            }
        }
        return librosPorAutor;
    }

    // Buscar Libro por Titulo

    public ArrayList<Libro> buscaPorTitulo (String TituloDelLibro){
        ArrayList<Libro> librosPorTitulo = new ArrayList<>();
        for (Material i: material){
            if (i instanceof Libro libro && libro.getNombre().equalsIgnoreCase(TituloDelLibro)) { 
                librosPorTitulo.add(libro); 
            }
        }
        return librosPorTitulo;
    }

    // buscar la localizacion del libro

    public String buscarLocalizacion (Material materialBuscado){
        for (int i=0; i < this.material.length; i ++) {
            if (this.material[i].equals(materialBuscado)){
                return this.material[i].getLocalizacion();
            }
        }
        return "material no existente";
    }

    
}
