package modelo;
public class Material {
    
    private String nombre;
    private String lenguaje;
    private String autor;
    private String editorial;
    private int anioDePublicacion; 
    private String localizacion;
    protected int copias;

    public Material(String nombre, String lenguaje, String autor, String editorial, 
    int anioDePublicacion, String localizacion, int Copias){

        this.nombre = nombre;
        this.lenguaje = lenguaje;
        this.autor = autor;
        this.editorial = editorial;
        this.anioDePublicacion = anioDePublicacion;
        this.localizacion = localizacion;
        

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLenguaje() {
        return lenguaje;
    }

    public void setLenguaje(String lenguaje) {
        this.lenguaje = lenguaje;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public int getAnioDePublicacion() {
        return anioDePublicacion;
    }

    public void setAnioDePublicacion(int anioDePublicacion) {
        this.anioDePublicacion = anioDePublicacion;
    }

    public String getLocalizacion() {
        return localizacion;
    }

    public void setLocalizacion(String localizacion) {
        this.localizacion = localizacion;
    }

    public int getCopias() {
        return copias;
    }

    public void setCopias(int copias) {
        this.copias = copias;
    }

}