package modelo;

public class Servicios {
    
    Boolean agendarCharla;
    Boolean agendarActividad;

    public Servicios(Boolean agendarCharla, Boolean agendarActividad){
        this.agendarActividad = agendarActividad;
        this.agendarCharla = agendarCharla;
    }

    public Boolean getAgendarCharla() {
        return agendarCharla;
    }

    public void setAgendarCharla(Boolean agendarCharla) {
        this.agendarCharla = agendarCharla;
    }

    public Boolean getAgendarActividad() {
        return agendarActividad;
    }

    public void setAgendarActividad(Boolean agendarActividad) {
        this.agendarActividad = agendarActividad;
    }

    
}
