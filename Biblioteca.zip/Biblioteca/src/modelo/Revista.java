package modelo;
import java.util.ArrayList;

public class Revista extends Material {

    private int diaDePublicacion;
    private int mesDePublicacion;
    private int cantidad;
    private ArrayList<EjemplarLibro> copias;

    public Revista(String nombre, String lenguaje, String genero, String autor, String editorial, int anioDePublicacion,
            int diaDePublicacion, int mesDePublicacion, String localizacion, int copias) {
        super(nombre, lenguaje, genero, autor, anioDePublicacion, localizacion,copias);
        this.diaDePublicacion = diaDePublicacion;
        this.mesDePublicacion = mesDePublicacion;
    }
    public int getDiaDePublicacion() {
        return diaDePublicacion;
    }
    public void setDiaDePublicacion(int diaDePublicacion) {
        this.diaDePublicacion = diaDePublicacion;
    }
    public int getMesDePublicacion() {
        return mesDePublicacion;
    }
    public void setMesDePublicacion(int mesDePublicacion) {
        this.mesDePublicacion = mesDePublicacion;
    }
    
    //metodo adicionar revistas

    

    //metodo para eliminar revistas

    

}
