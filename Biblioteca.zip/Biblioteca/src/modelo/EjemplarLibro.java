package modelo;
public class EjemplarLibro {
    
    private boolean estaDisponible = true;
    private Libro refLibro;
   
    public EjemplarLibro(Libro copiaLibro) {
        this.refLibro = copiaLibro;
    }

    public Libro getRefLibro() {
        return refLibro;
    }

    
    

   
}