package principal;

import modelo.Game;

public class Principal {
    public static void main(String[] args) {
        Game game = new Game("JDRO", "Bruh");
        game.start();
    }


    //Bugs
    //- No termina partida cuando no hay barcos
    //- No se guarda el daño cuando se cambia de posicion el barco
    //- Al darle un numero diferente de las opciones en la pantalla se salta el turno
    // Error
    //- Al darle String y no un numero sale un error, implementar que con ese error muestre el mensaje ""


}
