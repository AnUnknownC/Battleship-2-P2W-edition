package modelo;

import java.util.ArrayList;
import java.util.List;

public class Board {
    private int size;
    private char[][] grid;
    private List<Ship> ships;

    public Board() {
        this.size = 20; //El tamaño original seran 20, pero prueben con 10 para que vean como funciona
        grid = new char[size][size];
        ships = new ArrayList<>();
        initializeGrid();
    }

    public int getSize() {
        return size;
    }

    /// ----------------------------- ///

    /* Verificara si se puede colocar un barco */
    public boolean canPlaceShip(Ship ship) {
        // se crea una variable con la posicion inicial del barco
        Position start = ship.getStartPosition();
        // se recorre la longitud del barco y se crean nuevas variables para las coordenadas
        for (int i = 0; i < ship.getShipLength(); i++) {
            int row = start.getRow() + (ship.isHorizontal() ? 0 : i);
            int col = start.getColumn() + (ship.isHorizontal() ? i : 0);

            /* Verificar que las filas y columnas no salgan del mapa y que la celda sea diferente de '-' */
            // se puede cambiar por el metodo de isValidPosition? Si. Quiero hacerlo? No. Por que? Por que no me acordaba de ese metodo
            if (row < 0 || col < 0 || row >= size || col >= size || grid[row][col] != '-') {
                return false;
            }
        }
        return true;
    }

    /* Metodo para colocar colocar un barco en la celda */
    public void placeShipOnGrid(Ship ship) {
        // se crea una variable con la posicion inicial del barco
        Position start = ship.getStartPosition();
        // se recorre la longitud del barco y se crean nuevas variables para las coordenadas
        for (int i = 0; i < ship.getShipLength(); i++) {
            int row = start.getRow() + (ship.isHorizontal() ? 0 : i);
            int col = start.getColumn() + (ship.isHorizontal() ? i : 0);
            grid[row][col] = 'H'; // La cuadricula elegida por el metodo de getStartPosition y en esas coordenadas se pondra el puto barco 'H' -> barco
        }
    }

    /*
     * Metodo para mover el barco Se pedira por parametro el barco a elegir, la nueva posicion y orientacion
     */
    public boolean moveShip(Ship ship, Position newStart, boolean newOrientation) {
        clearShipFromGrid(ship); // Limpia el barco del tablero actual con el metodo de abajo

        // Actualiza la posición y orientación del barco
        ship.updatePosition(newStart, newOrientation);
        // verificara si es posible colocar el barco (asegurarse que no haya otro barco o impacto)
        if (canPlaceShip(ship)) {
            placeShipOnGrid(ship); // Coloca el barco en la nueva posición con el metodo de arriba
            return true; // Retornara true para indicar que el movimiento fue exitoso
        } else {
            // Si no se puede mover, revertir a la posición original
            ship.updatePosition(ship.getStartPosition(), ship.isHorizontal());
            placeShipOnGrid(ship); // Coloca el barco de vuelta en la posición original
            return false; // Movimiento fallido
        }
    }

    /* Es obligatorio Borrar el barco de su posicion para que no haya un barco fantasma por ahi */
    public void clearShipFromGrid(Ship ship) {
        // se crea una variable que guarde la posicion inicial del barco
        Position start = ship.getStartPosition();
        /*  Se recorrera la longitud del barco y se crearan las variables que se colocaran
        en el celda para ser remplazadas por '-' */
        for (int i = 0; i < ship.getShipLength(); i++) {
            int row = start.getRow() + (ship.isHorizontal() ? 0 : i);
            int col = start.getColumn() + (ship.isHorizontal() ? i : 0);
            grid[row][col] = '-';
        }
    }

    public void initializeGrid() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                grid[i][j] = '-'; // '-' -> es agua
            }
        }
    }

    public boolean addShip(Ship ship) {
        // Realizar un for each para verificar que no haya nada en el "agua"
        for (Position pos : ship.getPositions()) {
            // si la primera validacion (abajo), o si en las celda hay algo diferente de '-' retorna falso
            if (!isValidPosition(pos) || grid[pos.getRow()][pos.getColumn()] != '-') {
                return false;
            }
        }
        for (Position pos : ship.getPositions()) {
            grid[pos.getRow()][pos.getColumn()] = 'H'; // H -> este será el barco
        }
        ships.add(ship); // se añade el barco luego de verificar sus posiciones
        return true;
    }


    /*     *Actualizar el tablero si hay ataque*
     *  Se creara otro char que almacenara las celdas
     *  y si en alguna de esas celdas se encuentra la
     *  condicion pues hara lo que dice abajo.
     */
    public boolean attack(Position position) {
        // si la posicion no cumple con la validacion, lo toma como falso, osea como si se saliera del tablero el ataque
        if (!isValidPosition(position)) return false;
        char current = grid[position.getRow()][position.getColumn()];
        if (current == 'H') {
            grid[position.getRow()][position.getColumn()] = 'X'; // 'X' representa un golpe
            return true;
        } else if (current == '-') {
            grid[position.getRow()][position.getColumn()] = 'O'; // 'O' representa agua
        }
        return false;
    }

    /*
     *  Delimitacion del mapa las filas y columnas no pueden ser negativas, pero tampoco mayores al tamaño del mapa
     */
    private boolean isValidPosition(Position pos) {
        return pos.getRow() >= 0 && pos.getRow() < size && pos.getColumn() >= 0 && pos.getColumn() < size;
    }

    /*
     * Como cada jugador tendra su tablero sera necesario
     * que se imprima por pantalla, pero el metodo será
     * llamado en la clase jugador para lograr lo
     * anterior
     */
    public void display() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                System.out.print(grid[i][j] + " ");
            }
            System.out.println();
        }
    }
}
