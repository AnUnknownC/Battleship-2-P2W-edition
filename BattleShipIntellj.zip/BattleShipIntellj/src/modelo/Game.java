package modelo;

public class Game {
    private Player player1;
    private Player player2;

    public Game(String player1Name, String player2Name) {
        player1 = new Player(player1Name);
        player2 = new Player(player2Name);
    }

    // De algun lado tendra que arrancar el juego master
    public void start() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Battleship!");

        /*  Bueno aca veo un problema por ahora y es que toca configurar los barcos uno por uno. No se me ocurre como dejarlos todos listos y aparte de todo no se como hacer bien lo de orientacion, aunque lo pida */

        // De pronto un bucle para pedir más barcos¿ IDK pero por ahora esto queda como una prueba

        /* Para la sintaxis de esta cosa, llaman la variable, luego el metodo del tablero (cada uno tiene el suyo), despues crean el barco y les pedira una posicion, orientacion y longitud en la posicion añaden una nueva posicion por eso lo de la clase aparte y ya :) */
        player1.placeShip(new Ship(new Position(7, 7), 4, true));
        // player1.placeShip(new Ship(new Position(5, 5), 2, false));
        // player1.placeShip(new Ship(new Position(6, 0), 1, true));
        // player1.placeShip(new Ship(new Position(4, 4), 5, false));

        player2.placeShip(new Ship(new Position(2, 2), 6, false));
        // player2.placeShip(new Ship(new Position(7, 8), 2, true));
        // player2.placeShip(new Ship(new Position(0, 10), 3, false));
        // player2.placeShip(new Ship(new Position(5, 5), 5, true));

        Player currentPlayer = player1;
        Player opponent = player2;

        // De algun lado tendra que arrancar el juego master
        while (!player1.hasLost() || !player2.hasLost()) {

            /* Bueno aca se muestra el tablero y se le pide al jugador si mover o atacar */
            System.out.println("Turno de: " + currentPlayer.getName() );
            currentPlayer.displayBoard();
            System.out.println("1. Atacar\n2. Mover barco");
            int choice = scanner.nextInt();


            if (choice == 1) {
                // Se le piden las coordenadas
                System.out.print("Ingrese cordenadas de ataque (FILA COLUMNA): ");
                int row = scanner.nextInt();
                int col = scanner.nextInt();
                // si da pues le quita 1hp al enemigo y sube su racha de bajas
                if (currentPlayer.attack(opponent, new Position(row, col))) {
                    System.out.println("-1hp!" + "KillStreak: " + currentPlayer.getKillStreak());
                } else {
                    System.out.println("Miss!");
                }
                //No quiero comentar esto
                // Si el tamaño del array de rachas del jugador actual es mayor a 0, (obvio de tiene que cumplir la condicion de los puntos de la clase player)
                if (currentPlayer.getStreak().size() > 0) {
                    // se le pregunta si desea una racha
                    System.out.println("Desea Usar una racha? (UAV, AirStrike, Nuke) (si/no)");
                    String useStreak = scanner.next();

                    if(useStreak.equalsIgnoreCase("si")) {
                        // se pregunta cual se desea utilizar
                        System.out.println("Cual desea usar? (UAV/AirStrike/Nuke)");
                        String chooseStreak = scanner.next();

                        // Si es elegido el UAV, se utilizara el metodo creado en player
                        if (chooseStreak.equalsIgnoreCase("UAV")){
                            currentPlayer.useUAV(opponent);
                            // si se elige el AirStrike Se le pedira al jugador nuevas coordenadas para un ataque
                        } else if (chooseStreak.equalsIgnoreCase("AirStrike")) {
                            System.out.println("Ingrese las coordenadas (FILA COLUMNA): ");
                            int airStikeRow = scanner.nextInt();
                            int airStikecol = scanner.nextInt();
                            currentPlayer.useAirstrike(opponent, new Position(airStikeRow, airStikecol));
                            // si se elige la nuke pues bueno eso.
                        } else if (chooseStreak.equalsIgnoreCase("Nuke")) {
                            currentPlayer.useNuke(opponent);
                        } else {
                            System.out.println("Recompensa Invalida");
                        }
                    }
                } else {
                    System.out.println("-------------------------------------------------"); // Salto de linea
                }

            } else if (choice == 2) {
                // Se le pide el numero del barco que desee mover
                System.out.println("Seleccione el número del barco que desea mover:");

                // Muestra los barcos para elegir
                for (int i = 0; i < currentPlayer.getShipCount(); i++) {
                    System.out.println(i + ". Barco de longitud " + currentPlayer.getShip(i).getShipLength());
                }

                // Se elige el barco
                int shipIndex = scanner.nextInt();

                // Se le piden las nuevas cordenadas y orientacion almacenandoce en nuevas variables
                System.out.print("Ingrese la nueva fila: ");
                int newRow = scanner.nextInt();
                System.out.print("Ingrese la nueva columna: ");
                int newCol = scanner.nextInt();
                System.out.print("Ingrese la nueva orientación (true para horizontal, false para vertical): ");
                boolean newOrientation = scanner.nextBoolean();

                // Se crea un objeto posicion para meter por parametro lo anterior

                Position newPosition = new Position(newRow, newCol);
                // se accede al tablero del jugador, al metodo de mover barco y se pasan los parametros

                currentPlayer.getBoard().moveShip(currentPlayer.getShip(shipIndex), newPosition, newOrientation);

                //Misma vaina que la de arriba
                if (currentPlayer.getStreak().size() > 0) {
                    System.out.println("Desea Usar una racha? (UAV, AirStrike, Nuke) (si/no)");
                    String useStreak = scanner.next();

                    if(useStreak.equalsIgnoreCase("si")) {
                        // se pregunta cual se desea utilizar
                        System.out.println("Cual desea usar? (UAV/AirStrike/Nuke)");
                        String chooseStreak = scanner.next();

                        // Si es elegido el UAV, se utilizara el metodo creado en player
                        if (chooseStreak.equalsIgnoreCase("UAV")){
                            currentPlayer.useUAV(opponent);
                            // si se elige el AirStrike Se le pedira al jugador nuevas coordenadas para un ataque
                        } else if (chooseStreak.equalsIgnoreCase("AirStrike")) {
                            System.out.println("Ingrese las coordenadas (FILA COLUMNA): ");
                            int airStikeRow = scanner.nextInt();
                            int airStikecol = scanner.nextInt();
                            currentPlayer.useAirstrike(opponent, new Position(airStikeRow, airStikecol));
                            // si se elige la nuke pues bueno eso.
                        } else if (chooseStreak.equalsIgnoreCase("Nuke")) {
                            currentPlayer.useNuke(opponent);
                        } else {
                            System.out.println("Recompensa Invalida");
                        }
                    }
                } else {
                    System.out.println("----------------------------------------- "); // Otro salto de linea
                }
            }



            // Para alterar el jugador se me ocurrio esto, esta medio rebuscado
            /* Se guarda al jugador actual en una variable temporal y ahora se asigna al rival como el nuevo oponente, una vez juegue el rival pasara a ser almacenada en la variable temporal (Guardando todos los movimientos tambien) */
            Player temp = currentPlayer;
            currentPlayer = opponent;
            opponent = temp;
        }

        // No se como hacer para que el juego se termine, estan los metodos pero ya tengo el cerebro recalentado
        System.out.println("Game Over! " );
        scanner.close();
    }
}

