package modelo;



public class Ship {
    private Position startPosition;
    private int length;
    private boolean isHorizontal;
    private boolean[] hits;

    public Ship(Position startPosition, int length, boolean isHorizontal) {
        this.startPosition = startPosition;
        this.length = length;
        this.isHorizontal = isHorizontal;
        this.hits = new boolean[length]; //no hay impactos al inicio
    }


    public Position getStartPosition(){
        return startPosition;
    }

    public boolean isHorizontal() {
        return isHorizontal;
    }

    public int getShipLength() {
        return length;
    }

    public void setStartPosition(Position startPosition) {
        this.startPosition = startPosition;
    }

    // Unicamente es como un set de posicion y orientacion
    public void updatePosition(Position newPosition, boolean newOrientation) {
        this.startPosition = newPosition;
        this.isHorizontal = newOrientation;
    }

    /// ----------------------------------------------- ///


    /* Nuevo metodo de saber si esta hundido, va a recorrer el array booleano de hits si no hay ninguno retrona falso, y si no pues true */
    public boolean isSunken() {
        for (boolean hit : hits) {
            if (!hit) return false;
        }
        return true;
    }


    public void hit(int partShip) {
        if (partShip >= 0 && partShip < length) {
            hits[partShip] = true;
        }
    }

    // Aca es para saber si ha sido golpeado, en este caso verificara que parte especifica del barco estamos mirando
    public boolean isHit(int verifyPart) {
        /* ej el barco tiene 3 partes (va de 0 -> 2) el primero verificara que el indice no sea negativo y el otro verificara que no se salga de la longitud del barco. Por ultimo si todo lo que haya dentro de hits es true significa que el barco
        fue golpeado */
        return verifyPart >= 0 && verifyPart < length && hits[verifyPart];
    }


    /*
     *  Se crea un array de posiciones que sera igual a la  longitud del barco, esa longitud de va a recorrer por medio de un ciclo for, al recorrerlo. Se añadiran dos variables para añadirlas a la posicion. para retornar esa posicion, es decir las posiciones ocupadas por el barco
     */
    public Position[] getPositions() {
        Position[] positions = new Position[length];
        for (int i = 0; i < length; i++) {
            int row = startPosition.getRow() + (isHorizontal ? 0 : i);
            /*      Bienvenidos a los ternarios monos
             * condicion ? valorSiesVerdadero : valorSiEsFalso (sintaxis)
             * es un if else mega compacto
             *
             * Entonces un ejemplo practico. la posicion de la fila (row) es 1 + (supongamos que isHorizontal es
             * igual a true). Entonces selecionara siempre el valor de la izquierda es decir el 0, por lo que row sera
             * 1 + 0;
             */
            int col = startPosition.getColumn() + (isHorizontal ? i : 0);
            positions[i] = new Position(row, col);
        }
        return positions;
    }
}
