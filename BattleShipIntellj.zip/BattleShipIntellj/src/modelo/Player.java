package modelo;

import java.util.ArrayList;
import java.util.List;

public class Player {
    private String name;
    private Board board;
    private List<Ship> ships;
    private int killStreak;
    private ArrayList<String> streak;

    public Player(String name) {
        this.name = name;
        this.board = new Board();
        this.ships = new ArrayList<>();
        this.killStreak = 0;
        this.streak = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public int getKillStreak(){
        return killStreak;
    }

    public ArrayList<String> getStreak(){
        return streak;
    }

    public Board getBoard() {
        return board;
    }

    public Ship getShip(int index) {
        if (index >= 0 && index < ships.size()) {
            return ships.get(index);
        } else {
            return null;
        }
    }

    public int getShipCount() {
        return ships.size();
    }

    /// ----------------------------------- ///

    /*
     * Aca se añade el barco a la lista de barcos
     * si y solo si en el metodo de barco es verdadero
     * (Osea que se añade un barco)
     */
    public boolean placeShip(Ship ship) {
        if (board.addShip(ship)) {
            ships.add(ship);
            return true;
        }
        return false;
    }

    // Ahora si el verdadero metodo de attack
    public boolean attack(Player opponent, Position position) {
        boolean hit = opponent.board.attack(position);
        if(hit){
            killStreak++;
            unlockStreak();
        }else{
            killStreak = 0;
        }
        return hit;

    }


    /*
     * Metodo para desbloquear las rachas
     */
    private void unlockStreak(){

        if (killStreak == 3 && !streak.contains("UAV")){

            streak.add("UAV");
            System.out.println(name + " UAV disponible");

        } else if (killStreak == 5 && !streak.contains("AirStrike")) {

            streak.add("AirStrike");
            System.out.println(name + " Atencion, AirStrike Disponible!");

        } else if (killStreak == 1 && !streak.contains("Nuke")) {

            streak.add("Nuke");
            System.out.println(name + "¡Alerta de nuke. Estado: Dispoible");
        }


    }

    /*
     *  Se hara una condicion para saber si esta disponible, mostrara el tablero enemigo y si no pues no hay puntos
     */
    public void useUAV (Player opponent) {
        if(streak.contains("UAV")){ // contains() toma una secuencia de char y lo vuelve un string. El punto es que busca el string que se pide
            System.out.println(name + "Desplegando UAV...");
            opponent.board.display();
            streak.remove("UAV");
        } else {
            System.out.println("No hay suficientes puntos");
        }
    }

    /*
     *  se verifica si hay disponible el airstrike, si es el caso le dara al oponente un nuevo chance para atacar
     */
    public void useAirstrike(Player opponent, Position position) {
        if (streak.contains("AirStrike")) {
            System.out.println(name + " is using AirStrike on " + position);
            boolean hit = opponent.board.attack(position);
            if (hit) {
                System.out.println("-1hp");
                killStreak++; // Mantiene la racha
            } else {
                System.out.println("Miss!");
                killStreak = 0; // Reinicia la racha
            }
            streak.remove("AirStrike"); // Elimina la recompensa después de usarla
        } else {
            System.out.println("No AirStrike available.");
        }
    }

    /* Vamoh a nukear
     *  si esta la racha disponible, se hara un recorrido por todo el tablero del oponente y se atacara a esas posiciones :potFriend:
     */
    public void useNuke(Player opponent){
        if(streak.contains("Nuke")){
            System.out.println(name + "3.. 2.. 1.." );
            for (int i = 0; i < opponent.board.getSize(); i++){
                for (int j = 0; j < opponent.board.getSize(); j++){
                    opponent.board.attack(new Position(i, j));
                }
            }
            System.out.println("BOOM!");
            streak.remove("Nuke");
        } else {
            System.out.println("Aun no hay suficientes puntos");
        }
    }




    /*  Se reccore el arrayList de barcos y si no cumple la condicion
    que esta en la clase barco pues no esta hundido, pero pasara por
    todos los barcos esa condicion */
    public boolean hasLost() {
        for (Ship ship : ships) {
            if (!ship.isSunken()) {
                return false;
            }
        }
        return true;
    }


    /* Como iba diciendo acá se tendra  que desplegar el tablero por cada jugador */
    public void displayBoard() {
        board.display();
    }

}


