public class Juego {
    
    private Jugador jugador1;
    private Jugador jugador2;
    private Tablero tablero1;
    private Tablero tablero2;
    private Tienda tienda;



}
